function Image({ url }) {
    return <img src={url} alt="Card" width="100" />;
  }

  export default Image;