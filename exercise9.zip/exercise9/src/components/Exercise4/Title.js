function Title({ text }) {
    return <h3>{text}</h3>;
  }
  
  export default Title;