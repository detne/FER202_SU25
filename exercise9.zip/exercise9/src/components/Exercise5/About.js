import { Container } from 'react-bootstrap';

function About() {
  return (
    <Container className="my-4 text-center" id="about">
      <h4><strong>About</strong></h4>
      <p>This is the about section of the website.</p>
    </Container>
  );
}

export default About;
