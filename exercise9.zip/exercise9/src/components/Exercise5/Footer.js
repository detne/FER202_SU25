function Footer() {
    return (
      <div style={{ backgroundColor: '#fcd283', padding: '1rem', textAlign: 'center' }}>
        <small>© 2023 Website. All rights reserved.</small>
      </div>
    );
  }
  
  export default Footer;
  